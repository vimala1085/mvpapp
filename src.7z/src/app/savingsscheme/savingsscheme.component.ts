import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-savingsscheme',
  templateUrl: './savingsscheme.component.html',
  styleUrls: ['./savingsscheme.component.css']
})
export class SavingsschemeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
